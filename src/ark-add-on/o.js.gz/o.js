var req,id2="debug",adi=new Map(),
    lang= navigator.language?navigator.language:navigator.browserLanguage?navigator.browserLanguage:navigator.userLanguage?navigator.userLanguage:navigator.systemLanguage?navigator.systemLanguage:"en";

lang=lang=="ru"?1:0;

adi={	ds: ["Data sending...","Передача данных..."],
	rrw:["The request received. Wait...","Запрос принят. Ждите..."],
	gd: ["Getting data...","Получение данных..."],
	ngd:["Couldn't get data: ","Не удалось получить данные: "],
	er2:["Error in the go2() function: ","Ошибка в функции go2(): "]
	};

function ltri(c){
return c.replace(/^(\s)+/g,'')}

function rtri(c){
return c.replace(/(\s)+$/g,'')}

function ale(x){
	document.getElementById(id2).innerHTML=x;
}

function wr(c){
	document.write(c);
}

function go(url2,j){
  if(req){req.abort()}
  req=null;
  try{req= new XMLHttpRequest()}catch(e){}
  if(req){
    var d=r=t=fi="",o
    try{o=document.getElementById(id2)}catch(e){}
    if(o){
      o.innerHTML=adi["ds"][lang];
      f=document.getElementsByTagName('FORM')[typeof(j)=="number"?j:0];
      if(typeof(f)=="object"){
        for(i=0; i<f.length ;i++){
          if(f[i].tagName=="INPUT"){
            t=f[i].type;
            if(t!="button"&&t!="reset"&&t!="submit"){
              if(t=="text"||t=="radio"){
                d+=f[i].value+"\t";
              }else{
                if(t=="checkbox"){
                  d+=(f[i].checked?"1":"")+"\t";
                }else{
                  r+=rand(f[i].value)+"\t";
                }
              }
            }else if(t=="file"||t=="image"){
              if(!fi){
                if(f[i].files.length) fi=f[i].files[0];
              }
            }
          }else{
            if(f[i].tagName=="TEXTAREA"){
              d+=f[i].value+"\t";
            }
          }
        }
      }else{
        if(!fi){
          let f=document.querySelector('input[type=file]');
          if(f && f.files.length) {
            var progress = document.getElementById('progress');
            if(progress && progress.innerHTML.length<3) fi=f.files[0];
          }
        }
      }
    }
    req.open("POST",url2,true);
    req.onreadystatechange=go1;
    if(fi && url2.indexOf("?")<0){
      req.upload.onprogress = function(e) {
          if (progress && e.lengthComputable) progress.innerHTML = Math.round(e.loaded/e.total*99)+"%";
      }
      req.send(fi);
    }else{
      req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
      req.send(encodeURIComponent(d)+r);
    }
  }
}

function go1(){
var o=document.getElementById(id2);
  try{
    switch(req.readyState){
    case 2:
      o.innerHTML=adi["rrw"][lang];
      break;
    case 3:
      o.innerHTML=adi["gd"][lang];
      break;
    case 4:
      if(req.status==200){
        o.innerHTML="";
        go2();
      }else{
        o.innerHTML=adi["ngd"][lang]+req.statusText;
      }
    }
  }catch(e){
    o.innerHTML=adi["er2"][lang]+e.name;
  }
}
