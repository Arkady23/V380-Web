var adic=new Map(),cSdcard,cInfo,cSett,cReb;

adic= { sdcard:	["SD-card&nbsp;records","Записи&nbsp;на&nbsp;sd-карте"],
	info:		["Camera Info","Сведения о камере"],
	sett:		["Settings","Настройки"],
	reb:		["Rebooting","Перезагрузка"],
	safoff:	["Safe shutdown of the camera","Безопасное отключение камеры"],
	for:		["for","за"],
	time:		["Time","Время"],
	fName:	["File name","Имя файла"],
	saveFl:	["Save<br>the file","Сохранить<br>файл"],
	noRec:	["There are no records","Записей нет"],
	rebCam:	["The camera reboot...","Камера перезагружается..."],
	camOff:	["The camera shuts down...","Камера отключается..."],
	camSh:	["The camera has shut down","Камера завершила работу"],
	sdcardC:	["Camera&nbsp;sd-card&nbsp;records","Записи&nbsp;на&nbsp;sd-картe&nbsp;камеры"],
	date:		["Date","Дата"],
	fold:		["Folder","Папка"],
	plst:		["Create<br>a playlist","Сформировать<br>плейлист"],
	plist1:	["Why is this necessary?","Зачем это нужно?"],
	plist2:	["Current Internet browsers may not play all video formats. "+
	"However, there are desktop applications that allow you to open and play video files, " +
	"hosted on the Internet or local network by URL.",
	"Современные обозреватели интернета могут воспроизводить не все форматы видео. "+
	"Однако существуют десктопные приложения, позволяющие открывать и воспроизводить видеофайлы, "+
	"размещенные в интернете или локальной сети по URL."],
	plist3:	["The most popular video player that provides such viewing is <a href='https://www.videolan.org/' "+
	"target= '_blank'>VLC media player</a>. A decent alternative suitable for V380 video cameras is a fairly "+
	"old and yet actively developing video player <a href='https://github.com/clsid2/mpc-hc' target='_blank'>"+
	"Media Player Classic (MPC)</a>, which in integration with the <a href='https://github.com/ytdl-org/youtube-dl' "+
	"target='_blank'>youtube-dl</a> module, allows you to fully play video records of cameras of many models, "+
	"including V380, by URL.",
	"Наиболее популярным видеплейером, обеспечивающим такой просмотр, является <a href='https://www.videolan.org/' "+
	"target='_blank'>VLC media player</a>. Достойной альтернативой подходящей для видеокамер "+
	"V380 является достаточно старый и тем не менее активно развивающимся видеоплайер "+
	"<a href='https://github.com/clsid2/mpc-hc' target='_blank'>Media Player Classic (MPC)</a>, который в "+
	"интегации с модулем <a href='https://github.com/ytdl-org/youtube-dl' target='_blank'>youtube-dl</a> "+
	"позволяет полноценно воспроизводить по URL видезаписи камер многих моделей, в том числе V380."],
	plist4:	["By downloading the playlist to your PC, match the extension .xspf to the VLC application, "+
	"and .mpcpl to the MPC-HC or MPC-HC 64 application, you can play any video record directly "+
	"from your camera's SD card.",
	"Загрузив плейлист на свой ПК, сопоставив расширение .xspf приложению vlc, а .mpcpl приложению mpc-hc "+
	"или mpc-hc64, вы сможете воспроизвести любую видезапись прямо с sd-карты вашей камеры."],
	infoS:	["System","Система"],
	infoN:	["Network","Локальная сеть"],
	info1:	["Camera Model","Модель камеры"],
	info2:	["Processor Model","Модель процессора"],
	info3:	["CPU architecture","Архитектура процессора"],
	info4:	["Firmware Version","Версия прошивки"],
	info5:	["Hardware Version","Версия драйверов"],
	info6:	["App Version","Версия ПО"],
	info7:	["Camera date and time","Дата и время камеры"],
	info8:	["Uptime","Время работы"],
	info9:	["Load Average","Средняя нагрузка"],
	info10:	["Free / Total Memory","Свободная / Общая память"],
	info11:	["Free disk space","Свободное место на диске"],
	info12:	["Free space on the sd-card","Свободное место на sd-карте"],
	info21:	["Local IP","IP-адрес"],
	info22:	["Netmask","Сетевая маска"],
	info23:	["Gateway","Шлюз"],
	info24:	["MAC-address","MAC-адрес"],
	info25:	["WiFi ESSID","WiFi-идентификатор"],
	info26:	["WiFi Strength","Уровень сигнала"],
	settG:	["General","Основные"],
	settA:	["Advanced","Дополнительные"],
	sett1:	["Enable or disable RTSP-server","Включить или отключить RTSP-сервер"],
	sett2:	["URL to SD stream","URL на SD поток"],
	sett3:	["URL to HD stream","URL на HD поток"],
	sett4:	["Enable or disable Telnet-server","Включить или отключить Telnet-сервер"],
	sett5:	["WARNING: Telnet is NOT a secure protocol and should be avoided. Enable only if it's really necessary","ПРЕДУПРЕЖДЕНИЕ: Telnet не является безопасным протоколом, и его следует избегать. Включать только в том случае, если это действительно необходимо"],
	sett6:	["Enable or disable FTP-server","Включить или отключить FTP-сервер"],
	sett9:	["Playlist format","Формат плейлистов"],
	sett10:	["Select your preferred playlist app","Выбрать предпочитаемое приложение для проигрывания плейлистов"],
	sett11:	["Offline mode","Автономный режим"],
	sett12:	["Disable the V380 app and cloud features","Отключить приложение V380 и облачные функции"],
	sett13:	["Enable or disable the Web-server","Включить или отключить Web-сервер"],
	sett14:	["WARNING: If disabled, you won't have access to this page","ПРЕДУПРЕЖДЕНИЕ: Если отключить, то у вас не будет доступа к этой странице"],
	sett15:	["Port","порт"],
	sett16:	["TCP port used by HTTP Server (usually 80)","TCP-порт, используемый HTTP-сервером (общепринято 80)"],
	sett17:	["Formatting the sd-card","Форматирование sd-карты"],
	sett18:	["Format the sd-card by saving the Web server","Форматировать sd-карту, сохранив Web-сервер"],
	sett21:	["Load file","Загрузить файл"],
	sett22:	["complete","завершено"],
	sett23:	["Update the Web-server","Обновить Web-сервер"],
	sett24:	["The changes take effect after you save the settings and reboot the camera","Изменения вступают в силу после сохранения настроек и перезагрузки камеры"],
	sett25:	["Save Settings","Сохранить настройки"],
	sett26:	["Saved","Сохранено"],
	format:	["Format","Форматировать"],
	fmtSD1:	["FORMAT the SD card?","ФОРМАТИРОВАТЬ SD-карту?"],
	fmtSD2:	["All video recordings on the sd-card will be deleted!!!","Все видеозаписи на sd-карте будут уничтожены!!!"],
	fmtSD3:	["When formatting is finished, the camera will reboot.","По окончанию форматирования камера перезагрузится."],
	fmt:		["the sd-card is formatted...","sd-карта форматируется..."]
	};
cSdcard	="<a href=\"javascript:menu();location.reload()\">"+adic["sdcard"][lang]+"</a>\r\n";
cInfo	="<a href=\"javascript:menu();main('info')\">"+adic["info"][lang]+"</a>\r\n";
cSett	="<a href=\"javascript:menu();main('sett')\">"+adic["sett"][lang]+"</a>\r\n";
cReb	="<a href=\"javascript:power()\">"+adic["reb"][lang]+"</a>\r\n";

function main(cMenu){
  document.getElementById("in1").innerHTML="<table style='padding-top:15px'>\r\n"+
	"<tr><td><td id='sdcard' width=250>"+(cMenu=='sdcard'?adic[cMenu][lang]:cSdcard)+
	"<tr><td><td id='info'>"+(cMenu=='info'?adic[cMenu][lang]:cInfo)+
	"<tr><td><td id='sett'>"+(cMenu=='sett'?adic[cMenu][lang]:cSett)+
	"<tr><td><td id='reb'>"+cReb+
	"<tr><td style='padding:8px 0 0 15px'><a id='off1' href=\"javascript:power('off')\">\r\n"+
	"<svg xmlns='http://www.w3.org/2000/svg' height='30px' viewBox='0 0 24 24' width='30px' fill='#12b6ea'><path d='M0 0h24v24H0z' fill='none'/><path d='M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42C17.99 7.86 19 9.81 19 12c0 3.87-3.13 7-7 7s-7-3.13-7-7c0-2.19 1.01-4.14 2.58-5.42L6.17 5.17C4.23 6.82 3 9.26 3 12c0 4.97 4.03 9 9 9s9-4.03 9-9c0-2.74-1.23-5.18-3.17-6.83z'/></svg>\r\n"+
	"</a>\r\n"+
	"<td id='off'><a href=\"javascript:power('off')\">"+adic["safoff"][lang]+"</a>\r\n"+
	"</table>";
  switch(cMenu){
  case 'sdcard':
	sdcard();
	break;
  case 'info':
	info();
	break;
  case 'sett':
	sett();
  }
}
function go2(){
  let tbody,row,htm,i;
  x=req.responseText;
  var dl=x.lastIndexOf("\t");
  if(dl<0){
    d=["",""];
  }else{
    d=x.split("\t");
    dl=d.length-1;
  }
  switch(d[1]){
  case 'folder':
    tbody=document.getElementById("body1");
    tbody.innerHTML="";
    if(dl>2){
      let fldr=d[2],pat="/RecFiles/",f1,f2,cl,m,
        htm="<h3 class='container'>"+adic["sdcard"][lang]+" "+adic["for"][lang]+" "+d[2].substr(6)+"-"+d[2].substr(4,2)+"-"+d[2].substr(0,4)+"</h3>\r\n"+
        "<hr class='tiny-margin'>\r\n"+
        "<video id='video' class='video vh' controls autoplay></video>\r\n"+
        "<table class='pl'><tr><th width=120 class='tc'>"+adic["time"][lang]+"<th width=120>"+adic["fName"][lang]+"<th width=100>"+adic["saveFl"][lang]+"\r\n";
      for(i=4;i<dl;){
        f1=d[++i].substr(15,2);
        f2=d[i].substr(17,2);
        f3=d[i].substr(19,2);
        f4=pat;
        if(d[i].substr(0,1)=="/"){
          cl="tc red";
          d[i]=d[i].substr(1);
          f4+=d[i];
        }else{
          cl="tc";
          f4+=d[2]+"/h"+f1+"/"+d[i];
        }
        m=((Number(f1)+Number(d[3]))*60+Number(f2)+Number(d[4]))%1440;
        f1=('0'+Math.trunc(m/60)).substr(-2);
        f2=('0'+(m%60)).substr(-2);
        htm+="<tr>\r\n"+
          "<td class=\""+cl+"\">"+f1+":"+f2+":"+f3+
          "<td><a href=\"javascript:document.getElementById('video').setAttribute('src','"+f4+"')\">"+d[i]+"</a>\r\n"+
          "<td><a href=\""+f4+"\" class=\"f18\">&#128190;</a>";
      }
      htm+="</table>";
      tbody.innerHTML=htm;
    }
    break;
  case 'info':
    document.getElementById('camera_model').innerHTML=d[2];
    document.getElementById('proc_model').innerHTML=d[3];
    document.getElementById('arch').innerHTML=d[4];
    document.getElementById('fw_version').innerHTML=d[5];
    document.getElementById('hardware_v').innerHTML=d[6];
    document.getElementById('app_v').innerHTML=d[7];
    document.getElementById('local_time').innerHTML=d[8];
    document.getElementById('uptime').innerHTML=d[9];
    document.getElementById('load_avg').innerHTML=d[10];
    document.getElementById('memory').innerHTML=d[11];
    document.getElementById('free_disk').innerHTML=d[12];
    document.getElementById('free_sd').innerHTML=d[13];
    document.getElementById('local_ip').innerHTML=d[14];
    document.getElementById('netmask').innerHTML=d[15];
    document.getElementById('gateway').innerHTML=d[16];
    document.getElementById('mac_addr').innerHTML=d[17];
    document.getElementById('wlan_essid').innerHTML=d[18];
    document.getElementById('wlan_str').innerHTML=d[19];
    break;
  case 'sett':
    htm="";
    document.getElementById('RTSP').checked=d[2]=="1";
    document.getElementById('TELNET').checked=d[3]=="1";
    document.getElementById('FTP').checked=d[4]=="1";
    document.getElementById('APP').innerHTML=
	"<option value='VLC'"+(d[5]=="VLC"?" selected":"")+">VLC</option>\r\n"+
	"<option value='MPC'"+(d[5]=="MPC"?" selected":"")+">MPC</option>\r\n";
    document.getElementById('Cloud').checked=d[6]=="1";
    document.getElementById('HTTP').checked=d[7]=="1";
    document.getElementById('HTTP_PORT').value=d[8];
    break;
  case 'settsave':
    document.getElementById('save-status').innerHTML=adic["sett26"][lang];
    break;
  case 'load':
    document.getElementById('progress').innerHTML="100%";
    setTimeout(function(){window.location.href = window.location.href.replace(/#.*$/, '')},500);
    break;
  case 'test':
    location.reload();
    break;
  default:
    tbody=document.getElementById("body1").getElementsByTagName("TBODY")[0];
    if(dl<1){
      row=document.createElement("TR");
      row.innerHTML="<TD colspan='3' class='tc'>"+adic["noRec"][lang];
      tbody.appendChild(row);
    }else{
      for(i=0;i<dl;){
        row=document.createElement("TR");
        row.innerHTML="<TD class='tc'>"+d[++i].substr(6)+"-"+d[i].substr(4,2)+"-"+d[i].substr(0,4)+"<TD>"+
          "<a href=\"javascript:go('cgi-bin/sdcard.sh?"+d[i]+"')\">"+d[i]+"</a>"+"<TD><a href=\"javascript:splst('"+d[i]+"')\" class='f18' id='"+d[i]+"'>&#127916;</a>";
        tbody.appendChild(row);
      }
    }
  }
}

function menu(){
  document.getElementById("checkbox").click();
}
function fstatus(id,txt){
  document.getElementById(id).innerHTML=txt;
}
function power(off){
  document.getElementById('sdcard').innerHTML=cSdcard;
  document.getElementById('info').innerHTML=cInfo;
  document.getElementById('sett').innerHTML=cSett;
  if(off=="off"){
    go('cgi-bin/poweroff.sh');
    document.getElementById("off1").className="disabled";
    fstatus('off',adic["camOff"][lang]);
    setTimeout(function(){fstatus('off',adic["camSh"][lang])},15000);
  }else{
    go('cgi-bin/poweroff.sh?reset');
    fstatus('reb',adic["rebCam"][lang]);
    setTimeout(function(){location.reload()},64000);
  }
}
function sdcard(){
  go('cgi-bin/sdcard.sh');
  let fo=document.getElementById("body1");
  fo.innerHTML="<h3 class='container'>"+adic["sdcardC"][lang]+"</h3><hr class='tiny-margin'>\r\n"+
	"<div class='pl w40 u-pull-left'>\r\n"+
	"<table>\r\n"+
	"<tr><th width=150 class='tc'>"+adic["date"][lang]+"<th width=150>"+adic["fold"][lang]+"\r\n"+
	"<th width=120>"+adic["plst"][lang]+"&emsp;<a href='javascript:plist()' class='f18'>**</a>\r\n"+
	"</table>\r\n"+
	"</div><div class='w40 u-pull-left' id='col2'>\r\n"+
	"</div>\r\n";
;
}
function plist(){
  let fo=document.getElementById("col2");
  if(fo.innerHTML.length>10){
	fo.innerHTML="\r\n";
  }else{
	fo.innerHTML="<h4>"+adic["plist1"][lang]+"</h4>\r\n"+
		"<p class='jt'>\r\n"+
		adic["plist2"][lang]+"\r\n"+
		adic["plist3"][lang]+"\r\n"+
		adic["plist4"][lang]+"\r\n"+
		"</p>\r\n";
  }
}
function splst(p){
  let fo=document.getElementById(p);
  fo.className+=" disabled";
  location.assign('cgi-bin/splst.sh?'+p);
  setTimeout(function(){document.getElementById(p).className="f18"},10000);
}
function info(){
  go('cgi-bin/info.sh');
  let fo=document.getElementById("body1");
  fo.innerHTML="<h3 class='container'>"+adic["info"][lang]+"</h3><hr class='tiny-margin'>\r\n"+
	"<div class='container'>"+
	"<h5 class='tiny-margin strong'>"+adic["infoS"][lang]+"</h5><hr class='no-margin'>\r\n"+
	"<table class='u-full-width padded-table'>\r\n"+
	"<tr class='row'><td>"+adic["info1"][lang]+"<td id='camera_model'>\r\n"+
	"<tr><td>"+adic["info2"][lang]+"<td id='proc_model'>\r\n"+
	"<tr><td>"+adic["info3"][lang]+"<td id='arch'>\r\n"+
	"<tr><td>"+adic["info4"][lang]+"<td id='fw_version'>\r\n"+
	"<tr><td>"+adic["info5"][lang]+"<td id='hardware_v'>\r\n"+
	"<tr><td>"+adic["info6"][lang]+"<td id='app_v'>\r\n"+
	"<tr><td>"+adic["info7"][lang]+"<td id='local_time'>\r\n"+
	"<tr><td>"+adic["info8"][lang]+"<td id='uptime'>\r\n"+
	"<tr><td>"+adic["info9"][lang]+"<td id='load_avg'>\r\n"+
	"<tr><td>"+adic["info10"][lang]+"<td id='memory'>\r\n"+
	"<tr><td>"+adic["info11"][lang]+"<td id='free_disk'>\r\n"+
	"<tr><td>"+adic["info12"][lang]+"<td id='free_sd'>\r\n"+
	"</table>\r\n"+
	"<h5 class='tiny-margin strong'>"+adic["infoN"][lang]+"</h5><hr class='no-margin'>\r\n"+
	"<table class='u-full-width padded-table'>\r\n"+
	"<tr class='row'><td>"+adic["info21"][lang]+"<td id='local_ip'>\r\n"+
	"<tr><td>"+adic["info22"][lang]+"<td id='netmask'>\r\n"+
	"<tr><td>"+adic["info23"][lang]+"<td id='gateway'>\r\n"+
	"<tr><td>"+adic["info24"][lang]+"<td id='mac_addr'>\r\n"+
	"<tr><td>"+adic["info25"][lang]+"<td id='wlan_essid'>\r\n"+
	"<tr><td>"+adic["info26"][lang]+"<td id='wlan_str'>\r\n"+
	"</table>\r\n"+
	"</div>\r\n";
}
function delst(){
  document.getElementById('save-status').innerHTML="";
}
function settsave(){
  delst();
  x=document.getElementById('RTSP').checked?"1":"0";
  x+=document.getElementById('TELNET').checked?"1":"0";
  x+=document.getElementById('FTP').checked?"1":"0";
  x+=document.getElementById('APP').value;
  x+=document.getElementById('Cloud').checked?"1":"0";
  x+=document.getElementById('HTTP').checked?"1":"0";
  x+=document.getElementById('HTTP_PORT').value;
  go("cgi-bin/settsave.sh?"+x);
}
function fmtsd(){
  if(confirm("\n         "+adic["fmtSD1"][lang]+"\n\n         "+adic["fmtSD2"][lang]+"\n         "+adic["fmtSD3"][lang]+"\n")){
	document.getElementById('button-fmt').className="disabled";
	document.getElementById('fmt').innerHTML=adic['fmt'][lang];
	go('cgi-bin/fmtsd.sh');
	setTimeout(function(){go('cgi-bin/test.sh')},105000);
  }
}
function load(){
  let f=document.querySelector('input[type=file]');
  if(f && f.files.length){
    delst();
    document.getElementById('progress').innerHTML="0%";
    document.getElementById('progres2').innerHTML=adic["sett22"][lang];
    go("cgi-bin/load.sh");
    setTimeout(function(){document.getElementById('progress').innerHTML="100%"},67000);
    setTimeout(function(){location.reload()},70000);
  }
}
function sett(){
  go('cgi-bin/sett.sh');
  let fo=document.getElementById("body1");
  fo.innerHTML="<h3 class='container'>"+adic["sett"][lang]+"</h3><hr class='tiny-margin'>\r\n"+
	"<div class='container'>"+
	"<h5 class='tiny-margin strong'>"+adic["settG"][lang]+"</h5><hr class='no-margin'>\r\n"+
	"<table class='u-full-width padded-table config-table'>\r\n"+
	"<tr class='row'><td>RTSP "+(lang==1?"и":"and")+" ONVIF</td><td><label class='switch small'>"+
	"<input type='checkbox' id='RTSP' onchange='delst()'><span class='slider round'><span class='switch-text'></label>"+
	"<span class='switch-description'>"+adic["sett1"][lang]+".</span><br>\r\n"+
	"<span class='switch-description'>"+adic["sett2"][lang]+":&emsp;rtsp://"+location.hostname+"/live/ch00_0<br>"+
		adic["sett3"][lang]+":&emsp;rtsp://"+location.hostname+"/live/ch00_1<br>"+
		"ONVIF:&emsp;http://"+location.hostname+":8899/onvif/device_service"+
	"</span>\r\n"+
	"<tr class='row'><td>Telnet<td><label class='switch small'>"+
	"<input type='checkbox' id='TELNET' onchange='delst()'><span class='slider round'><span class='switch-text'></label>"+
	"<span class='switch-description'>"+adic["sett4"][lang]+".<br>"+
	"<span class='strong'>"+adic["sett5"][lang]+".</span></span>\r\n"+
	"<tr class='row'><td>FTP<td><label class='switch small'>"+
	"<input type='checkbox' id='FTP' onchange='delst()'><span class='slider round'><span class='switch-text'></label>"+
	"<span class='switch-description'>"+adic["sett6"][lang]+"."+
	"</table>\r\n"+
	"<h5 class='tiny-margin strong'>"+adic["settA"][lang]+"</h5><hr class='no-margin'>\r\n"+
	"<table class='u-full-width padded-table config-table'>\r\n"+
	"<tr class='row'><td>"+adic["sett9"][lang]+"</td><td><select class='u-full-width' id='APP' onchange='delst()'>\r\n"+
	"</select><span class='switch-description'>"+adic["sett10"][lang]+".\r\n"+
	"<tr class='row'><td>"+adic["sett11"][lang]+"<td><label class='switch small'>"+
	"<input type='checkbox' id='Cloud' onchange='delst()'><span class='slider round'><span class='switch-text'></label>"+
	"<span class='switch-description'>"+adic["sett12"][lang]+"."+
	"<tr class='row'><td>HTTP<td><label class='switch small'>"+
	"<input type='checkbox' id='HTTP' onchange='delst()'><span class='slider round'><span class='switch-text'></label>"+
	"<span class='switch-description'>"+adic["sett13"][lang]+".<br>"+
	"<span class='strong'>"+adic["sett14"][lang]+".</span></span>\r\n"+
	"<tr class='row'><td>HTTP "+adic["sett15"][lang]+"<td>\r\n"+
	"<input class='u-full-width' type='text' id='HTTP_PORT' onchange='delst()'>\r\n"+
	"<span class='switch-description'>"+adic["sett16"][lang]+".</span>\r\n"+
	"<tr class='row'><td>"+adic["sett17"][lang]+"</td><td><input class='button' type='button' id='button-fmt' value='"+adic["format"][lang]+"' onclick='fmtsd()'>&emsp;<span id='fmt'></span>\r\n"+
	"<div class='switch-description'>"+adic["sett18"][lang]+".\r\n"+
	"<tr class='row'><td><input class='button-primary' type='file' accept='application/x-tar'>\r\n"+
	"<td><input class='button' type='button' value='"+adic["sett21"][lang]+"' onclick='load()'>&emsp;<span id='progress'></span>&nbsp;<span id='progres2'></span>\r\n"+
	"<div class='switch-description'>"+adic["sett23"][lang]+".</div>\r\n"+
	"</table>\r\n"+
	"<div class='align-right'><span class='strong'>"+adic["sett24"][lang]+".</span>\r\n"+
	"</div><br>\r\n"+
	"<div class='u-pull-right'><div class='padded-right save-text' id='save-status'></div><input class='button-primary' type='button' id='button-save' value='"+adic["sett25"][lang]+"' onclick=\"settsave()\">\r\n"+
	"</div>\r\n"+
	"</div>\r\n";
}
